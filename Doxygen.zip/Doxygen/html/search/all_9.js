var searchData=
[
  ['transposition',['transposition',['../classmatrice.html#adae020db9b0b28e683a6957cb584db11',1,'matrice']]]
];
