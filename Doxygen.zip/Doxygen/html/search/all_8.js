var searchData=
[
  ['soustraction',['soustraction',['../classmatrice.html#a5d9d717f4eac564eb0a0297c6d1b5c94',1,'matrice']]]
];
