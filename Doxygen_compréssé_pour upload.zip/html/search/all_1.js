var searchData=
[
  ['battery_5ftest',['battery_test',['../classmatrice.html#a6dc19de5403fee2c5f03d74b712fb5f5',1,'matrice']]]
];
